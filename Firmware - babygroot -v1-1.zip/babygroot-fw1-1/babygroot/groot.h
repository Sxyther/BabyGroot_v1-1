/*********************************************************
* BabyGroot header file 
* Developed by @pp_ruiz @makersgdl in Guadalajara, Mexico
* Version 1.0
* info: https://github.com/Sxyther/BabyGroot_v1-0
**********************************************************/

#define uint8 unsigned char
#define MAX_ALARMS  5

#define GROOT_V1_1

#ifdef GROOT_V1_0
// Valve definition 
#define VALVE1  4
#define VALVE2  5
#define VALVE3  6
#define VALVE4  7
#define VALVE5  8
#endif

#ifdef GROOT_V1_1
// Valve definition 
#define VALVE1  3
#define VALVE2  5
#define VALVE3  6
#define VALVE4  10
#define VALVE5  7
#endif



#define DOMINGO   (1<<0) 
#define LUNES     (1<<1)  
#define MARTES    (1<<2)  
#define MIERCOLES (1<<3)  
#define JUEVES    (1<<4)  
#define VIERNES   (1<<5)  
#define SABADO    (1<<6)  


#define CERRADA LOW
#define ABIERTA HIGH


typedef struct{
  uint8 ghour;
  uint8 gminute;  
  uint8 gdays;  
}grootAlarm;

 /* Prototypes */
void grootRegisterAlarm(uint8 u8Alarm,uint8 u8hour,uint8 minutes,uint8 u8days,void (*f)());
void grootEnableAlarm(uint8 u8Alarm);
void grootInit(void);
void grootService(void);
void set_RTC_alarm(uint8,uint8);
void grootSetDateTime(uint8 ,uint8 ,uint8 ,uint8 ,uint8);
void grootTestValves(int u16Delay);
uint8 grootLookNextAlarm(uint8,uint8);
uint8 grootActivateNextAlarm(void);
uint8 DayOfWeek(struct ts );
void set_next_alarm(void);



